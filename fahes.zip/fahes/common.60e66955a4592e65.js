"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[592],{

/***/ 57599:
/*!***************************************************************!*\
  !*** ./src/app/core/models/adminstration/StationOperation.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationOperation": () => (/* binding */ StationOperation)
/* harmony export */ });
class StationOperation {}

/***/ }),

/***/ 67074:
/*!************************************************************!*\
  !*** ./src/app/core/services/application-admin.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplicationAdminService": () => (/* binding */ ApplicationAdminService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class ApplicationAdminService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'ApplicationAdmin/v1';
  }
  getLanes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneApplicationAdmin`, body);
  }
  getSections(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSectionApplicationAdmin`, body);
  }
  getBooths(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetBoothApplicationAdmin`, body);
  }
  getStationCategoryDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getStationCategoryDetails`, body);
  }
  stationCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/stationCategoryOperation`, body);
  }
  setBoothCamera(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/setBoothCamera`, body);
  }
  laneOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/LaneOperation`, body);
  }
  sectionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/SectionOperation`, body);
  }
  boothOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/BoothOperation`, body);
  }
  getUserAssignPosition(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetUserAssignPosition`, body);
  }
  userAssignPositionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/UserAssignPositionOperation`, body);
  }
  getLaneServiceType(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneServiceType`, body);
  }
  getLaneCategoryType(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneCategoryType`, body);
  }
  getInspectionSectionInstructions(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionSectionInstruction`, body);
  }
  instructionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/InstructionOperation`, body);
  }
  getStationInpsectionServiceTypes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetStationInpsectionServiceTypes`, body);
  }
  stationInspectionServiceTypeOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/StationInspectionServiceTypeOperation`, body);
  }
  getFeesCategoryDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesCategoryDetails`, body);
  }
  feesCategoryDetailsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesCategoryDetailsOperation`, body);
  }
  getFeesFormula(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesFormula`, body);
  }
  feesFormulaOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesFormulaOperation`, body);
  }
  getFeesFormulaDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesFormulaDetails`, body);
  }
  feesFormulaDetailsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesFormulaDetailsOperation`, body);
  }
  cloneFees(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/CloneFees`, body);
  }
  getStationByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetStationByServiceId`, body);
  }
  getCategoryByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetCategoryByServiceId`, body);
  }
  getPlateTypesByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetPlateTypesByServiceId`, body);
  }
  plateTypesServiceOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/PlateTypesServiceOperation`, body);
  }
  getDefectComments(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetDefectComments`, body);
  }
  defectCommentsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectCommentsOperation`, body);
  }
  defectMainCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectMainCategoryOperation`, body);
  }
  defectSubCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectSubCategoryOperation`, body);
  }
  GetVehicleDetailLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetVehicleDetails`, request);
  }
  VehicleDetailOperation(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/VehicleDetailsOperation`, request);
  }
  GetWaqodInstance(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetWaqodInstance`, request);
  }
  GetRegisteredVehicle(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/ViewRegisterVehicles`, request);
  }
  GetTermsAndConditin(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetActiveTermsAndConditin`, request);
  }
  GetDelegationLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetDelegationLst`, request);
  }
  POSTDelegation(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DelegationDML`, request);
  }
  GetcarAccessories(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetarAccessories`, request);
  }
  CarAccessoriesDML(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/CarAccessoriesDML`, request);
  }
  POSTTermsCondition(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/TermsConditionDML`, request);
  }
  GetsectionDevicesLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSectionDevices`, request);
  }
  sectionDevicesDml(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/sectionDevicesDml`, request);
  }
  static #_ = this.ɵfac = function ApplicationAdminService_Factory(t) {
    return new (t || ApplicationAdminService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: ApplicationAdminService,
    factory: ApplicationAdminService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 92498:
/*!*********************************************************!*\
  !*** ./src/app/core/services/visual-defects.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VisualDefectService": () => (/* binding */ VisualDefectService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class VisualDefectService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Inspection/v1';
  }
  getMainVisualDefects(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetMainVisualDefects`, body);
  }
  getSubVisualDefects(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSubVisualDefects`, body);
  }
  getSubVisualDefectsComments(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSubVisualDefectComments`, body);
  }
  getVehicleDefects(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetVehicleDefects`, {
      requestId: requestId
    });
  }
  createInspectionResult(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionResult`, body);
  }
  static #_ = this.ɵfac = function VisualDefectService_Factory(t) {
    return new (t || VisualDefectService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: VisualDefectService,
    factory: VisualDefectService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 48672:
/*!***************************************************************!*\
  !*** ./src/app/modules/backoffice/classes/payment-details.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetails": () => (/* binding */ PaymentDetails),
/* harmony export */   "SummaryDetails": () => (/* binding */ SummaryDetails)
/* harmony export */ });
class PaymentDetails {
  constructor() {
    this.paymentTypeId = 2;
  }
}
class SummaryDetails {}

/***/ })

}]);
//# sourceMappingURL=common.60e66955a4592e65.js.map